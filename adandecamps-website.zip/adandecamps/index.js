const express = require('express');
const i18n = require('i18n');
const cookieParser = require('cookie-parser');
const path = require('path');
// Load JS locale files
const enTranslations = require('./locales/en');
const esTranslations = require('./locales/es');

const translations = {
  en: enTranslations,
  es: esTranslations,
};

const app = express();
// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

app.use(cookieParser());
i18n.configure({
  locales: ['en', 'es'], // Available languages
  defaultLocale: 'es', // Default language
  cookie: 'lang', // Name of the cookie to store language preference
  directory: path.join(__dirname, '/locales'), // This is still required, but we'll use the manual approach for JS files
  autoReload: false,
  updateFiles: false,
  syncFiles: false, // We won't rely on auto-syncing files
});

app.use((req, res, next) => {
  const locale = req.cookies.lang || 'es'; // Default to English if no cookie is set
  i18n.setLocale(req, locale); // Use i18n for locale management

  // Manually add translation object for the current locale
  res.locals.__ = (key) => translations[locale][key] || key;

  next();
});

// Set view engine (EJS)
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Route to change language
app.get('/lang/:locale', (req, res) => {
  const locale = req.params.locale;
  res.cookie('lang', locale); // Save selected language in the cookie
  res.redirect('back');
});

// Route to render homepage
app.get('/', (req, res) => {
  res.render('index');
});

// Start the server
app.listen(5022, () => {
  console.log('Server is running on http://localhost:5022');
});
