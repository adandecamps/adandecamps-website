module.exports = {
	economist: "Economist",
	aboutme: "About me",
	services: "Services",
	contact: "Contact",
	aboutme_text: `Adán Rafael De Camps Martínez is an economist with a solid academic background, including a master's degree in finance with a specialization in the capital and stocks market. He is a columnist for the newspaper Hoy. He has knowledge of spanish, english and french.Throughout his career, he has gained experience in the regulatory organization of monetary and exchange policy, the state bank, and private banking in the Dominican Republic, which has given him a comprehensive perspective of financial and economic dynamics.

His professional career has been characterized by a commitment to the implementation of evidence-based public policies for economic development. In addition, he has worked in the structuring of public and private trusts, seeking innovative solutions to problems in the public and private spheres.

He has collaborated closely with the government in the formulation and implementation of policies that drive sustainable economic growth.
The focus is on capital and stocks market concentration, crucial areas that directly impact the financial stability of a nation.

The main objective is to apply economic and financial knowledge to address challenges in both the public and private spheres, maintaining a firm commitment to professional ethics.

Convinced of the transformative power of the economy to improve people's quality of life, he constantly seeks innovative ways to apply experience to address economic challenges, financial stability and business and social growth, finding comprehensive and sustainable solutions.`,
	service_1: `Consulting on economic and financial Issues`,
	service_2: `Trust structuring`,
	service_3: `Evidence-based public policy advice`,
	service_4: `Advice on investments in the stock market and capital market`,
	service_5: `Business intelligence`,
	service_6: `Data collection and presentation for informed decision-Making`,
	service_7: `Economic and financial research`,
	service_8: `Advice on investments in cryptocurrencies (cryptoassets)`,
	name: `Fullname`,
	email: `Email`,
	message: `Message`,
	send: `Send`,
}