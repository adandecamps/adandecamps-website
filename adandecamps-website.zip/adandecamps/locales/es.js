module.exports = {
    economist: "Economista",
    aboutme: "Sobre mi",
    services: "Servicios",
    contact: "Contacto",
aboutme_text: `Adán Rafael De Camps Martínez es economista con una sólida formación académica, incluyendo un máster en finanzas con especialización en el mercado de capitales y valores. Columnista del periódico Hoy. Tiene conocimientos de español, inglés y francés. A lo largo de su carrera, ha adquirido experiencia en la organización reguladora de la política monetaria y cambiaria, el banco estatal y la banca privada de la República Dominicana, lo que le ha brindado una perspectiva integral de las dinámicas financieras y económicas.

La trayectoria profesional se ha caracterizado por un compromiso con la implementación de políticas públicas basadas en evidencia para el desarrollo económico. Además, ha trabajado en la estructuración de fideicomisos tanto públicos como privados, buscando soluciones innovadoras a problemas del ámbito público y privado.

Ha colaborado estrechamente con el gobierno en la formulación e implementación de políticas que impulsan el crecimiento económico sostenible.
El enfoque se centra en la concentración del mercado de capital y valores, áreas cruciales que impactan directamente en la estabilidad financiera de una nación.

El objetivo principal es aplicar los conocimientos económicos y financieros para abordar desafíos tanto del ámbito público como del privado, manteniendo un firme compromiso con la ética profesional.
Convencido del poder transformador de la economía para mejorar la calidad de vida de las personas, busca constantemente maneras innovadoras de aplicar la experiencia para abordar desafíos económicos, de estabilidad financiera y crecimiento empresarial y sociales, encontrando soluciones integrales y sostenibles.`,
    service_1: `Consultoria en temas económicos y financieros`,
    service_2: `Estructuración de fideicomisos`,
    service_3: `Asesoramiento para políticas públicas basadas en evidencia`,
    service_4: `Asesoramiento para Inversiones en mercado de capitales y valores`,
    service_5: `Inteligencia de negocios`,
    service_6: `Levantamiento y presentación de datos para toma de decisiones informadas`,
    service_7: `Investigaciones económicas y financieras`,
    service_8: `Asesoramiento para inversiones en criptomonedas (criptoactivos)`,
    name: `Nombre`,
    email: `Email`,
    message: `Mensaje`,
    send: `Enviar`,
}